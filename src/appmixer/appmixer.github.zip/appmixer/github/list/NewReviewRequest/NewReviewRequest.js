'use strict';
const lib = require('../../lib');

/**
 * Component which triggers whenever new review is requested from a specified user
 * @extends {Component}
 */
module.exports = {

    async tick(context) {

        let { repositoryId, username } = context.properties;

        const query = `review-requested:${username}+repo:${repositoryId}+is:pr`;

        const result = await lib.apiRequest(context, `search/issues?q=${query}`);

        let known = Array.isArray(context.state.known) ? new Set(context.state.known) : null;
        const { diff, actual } = lib.getNewItems(known, result.data.items, 'id');

        if (diff.length) {
            await Promise.all(diff.map(result => {
                return context.sendJson(result, 'out');

            }));
        }
        await context.saveState({ known: actual });
    }
};

