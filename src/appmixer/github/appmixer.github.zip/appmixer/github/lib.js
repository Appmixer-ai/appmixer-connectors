'use strict';

const pathModule = require('path');

const DEFAULT_PREFIX = 'github-objects-export';

module.exports = {

    async apiRequest(context, action, {
        method = 'GET',
        body = {},
        params = {}
    } = {}) {

        const url = `https://api.github.com/${action}`;
        const options = {
            method,
            url,
            headers: {
                'accept': 'application/vnd.github+json',
                'X-GitHub-Api-Version': '2026-03-10',
                'Authorization': `Bearer ${context.accessToken || context.auth?.accessToken}`
            },
            data: body,
            params: {
                ...params,
                per_page: 100
            }
        };

        return await context.httpRequest(options);
    },

    async apiRequestPaginated(context, action, {
        method = 'GET',
        body = {},
        params = {}
    } = {}) {

        let items = [];
        let page = 1;
        let hasNextPage = true;

        while (hasNextPage) {
            const { data, headers } = await this.apiRequest(context, action, {
                method,
                body,
                params: {
                    ...params,
                    per_page: 100,
                    page
                }
            });

            items = items.concat(data);

            const linkHeader = headers.link;
            if (linkHeader) {
                const links = linkHeader.split(',').map(link => link.trim());
                const nextLink = links.find(link => link.includes('rel="next"'));
                hasNextPage = !!nextLink;
            } else {
                hasNextPage = false;
            }

            page++;
        }

        return items;
    },

    /**
     * Process items to find newly added.
     * @param knowItems
     * @param {Set} actualItems
     * @param {String} key
     */
    getNewItems(knowItems, actualItems, key) {

        const newItems = new Set();
        const actual = new Set();

        actualItems.forEach(item => {
            if (knowItems && !knowItems.has(item[key])) {
                newItems.add(item);
            }
            actual.add(item[key]);
        });

        return { diff: Array.from(newItems), actual: Array.from(actual) };
    },

    /**
     * Normalize multiselect input (array or string) to array format.
     * Strings are treated as single values or comma-separated lists.
     * @param {string|string[]} input
     * @param {object} context
     * @param {string} fieldName
     * @returns {string[]}
     */
    normalizeMultiselectInput(input, context, fieldName) {

        if (Array.isArray(input)) {
            return input;
        } else if (typeof input === 'string') {
            // Handle single string value or comma-separated string
            return input.split(',').map(item => item.trim()).filter(item => item.length > 0);
        } else {
            throw new context.CancelError(`${fieldName} must be a string or an array`);
        }
    },

    async sendArrayOutput({
        context,
        outputPortName = 'out',
        outputType = 'array',
        records = []
    }) {

        if (outputType === 'first') {
            if (records.length === 0) {
                throw new context.CancelError('No records available for first output type');
            }
            // One by one.
            await context.sendJson(
                { ...records[0], index: 0, count: records.length },
                outputPortName
            );
        } else if (outputType === 'object') {
            // One by one.
            for (let index = 0; index < records.length; index++) {
                await context.sendJson(
                    { ...records[index], index, count: records.length },
                    outputPortName
                );
            }
        } else if (outputType === 'array') {
            // All at once.
            return await context.sendJson({ result: records, count: records.length }, outputPortName);
        } else if (outputType === 'file') {

            // Into CSV file.
            const csvString = toCsv(records);

            let buffer = Buffer.from(csvString, 'utf8');
            const componentName = context.flowDescriptor[context.componentId].label || context.componentId;
            const fileName = `${context.config.outputFilePrefix || DEFAULT_PREFIX}-${componentName}.csv`;
            const savedFile = await context.saveFileStream(pathModule.normalize(fileName), buffer);

            await context.log({ step: 'File was saved', fileName, fileId: savedFile.fileId });
            await context.sendJson({ fileId: savedFile.fileId }, outputPortName);
        } else {
            throw new context.CancelError('Unsupported outputType ' + outputType);
        }
    },

    getProperty(obj, path) {
        return path.split('.').reduce((acc, part) => acc?.[part], obj);
    },

    getOutputPortOptions(context, outputType, itemSchema, { label }) {

        if (outputType === 'object' || outputType === 'first') {
            const options = Object.keys(itemSchema)
                .reduce((res, field) => {
                    const schema = itemSchema[field];
                    const { title: label, ...schemaWithoutTitle } = schema;

                    res.push({
                        label, value: field, schema: schemaWithoutTitle
                    });
                    return res;
                }, [{
                    label: 'Current Item Index',
                    value: 'index',
                    schema: { type: 'integer' }
                }, {
                    label: 'Items Count',
                    value: 'count',
                    schema: { type: 'integer' }
                }]);

            return context.sendJson(options, 'out');
        }

        if (outputType === 'array') {
            return context.sendJson([{
                label: 'Items Count',
                value: 'count',
                schema: { type: 'integer' }
            }, {
                label: label,
                value: 'result',
                schema: {
                    type: 'array',
                    items: { type: 'object', properties: itemSchema }
                }
            }], 'out');
        }

        if (outputType === 'file') {
            return context.sendJson([{ label: 'File ID', value: 'fileId' }], 'out');
        }
    }

};

/**
 * @param {array} array
 * @returns {string}
 */
const toCsv = (array) => {
    const headers = Object.keys(array[0]);

    return [
        headers.join(','),

        ...array.map(items => {
            return Object.values(items).map(property => {
                if (typeof property === 'object') {
                    return JSON.stringify(property);
                }
                return property;
            }).join(',');
        })

    ].join('\n');
};
