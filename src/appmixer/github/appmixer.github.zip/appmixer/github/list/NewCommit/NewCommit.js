'use strict';
const lib = require('../../lib');

/**
 * Component which triggers whenever new commit is created
 * @extends {Component}
 */
/**
 * Maximum number of IDs to retain in context.state.known.
 * getNewItems() replaces (not accumulates) known each tick, so this cap only
 * fires if a single tick returns an unusually large page of results.
 */
const MAX_KNOWN = 500;

module.exports = {

    async tick(context) {

        const { repositoryId, branchId } = context.properties;

        const params = {};
        if (branchId) {
            params.sha = branchId;
        }

        const res = await lib.apiRequest(context, `repos/${repositoryId}/commits`, { params });

        const known = Array.isArray(context.state.known) ? new Set(context.state.known) : null;

        const { diff, actual } = lib.getNewItems(known, res.data, 'sha');
        if (diff.length) {
            await Promise.all(diff.map(commit => context.sendJson(commit, 'commit')));
        }
        const trimmedKnown = actual.length > MAX_KNOWN ? actual.slice(actual.length - MAX_KNOWN) : actual;
        await context.saveState({ known: trimmedKnown });
    }
};
