'use strict';
const ClickUpClient = require('../../ClickUpClient');

module.exports = {

    async receive(context) {

        const {
            taskId,
            name,
            description,
            status,
            priority,
            dueDate,
            dueDateTime,
            startDate,
            startDateTime,
            notifyAll,
            parent,
            archived
        } = context.messages.in.content;
        if (!taskId) {
            throw new context.CancelError('Task ID is required');
        }


        const clickUpClient = new ClickUpClient(context);

        const taskData = {
            name,
            description,
            status,
            priority,
            due_date: dueDate && Date.parse(dueDate),
            due_date_time: dueDateTime,
            start_date: startDate && Date.parse(startDate),
            start_date_time: startDateTime,
            notify_all: notifyAll,
            parent,
            archived
        };

        const createdTask = await clickUpClient.request('PUT', `/task/${taskId}`, { data: taskData });

        return context.sendJson(createdTask, 'out');
    }
};
